import {
  ButtonInteraction,
  InteractionReplyOptions,
  InteractionEditReplyOptions,
  MessageFlags,
} from "discord.js";

export class ButtonResponse {
  /**
   * Defer an ephemeral button interaction.
   */
  public static async defer(
    interaction: ButtonInteraction
  ): Promise<void> {
    if (interaction.deferred || interaction.replied) {
      return;
    }

    await interaction.deferReply({
      flags: MessageFlags.Ephemeral,
    });
  }

  /**
   * Send an initial reply.
   */
  public static async reply(
    interaction: ButtonInteraction,
    options: InteractionReplyOptions
  ): Promise<void> {
    await interaction.reply(options);
  }

  /**
   * Edit a deferred or replied interaction.
   */
  public static async edit(
    interaction: ButtonInteraction,
    options: string | InteractionEditReplyOptions
  ): Promise<void> {
    if (typeof options === "string") {
      await interaction.editReply({
        content: options,
      });

      return;
    }

    await interaction.editReply(options);
  }

  /**
   * Send a follow-up message.
   */
  public static async followUp(
    interaction: ButtonInteraction,
    options: InteractionReplyOptions
  ): Promise<void> {
    await interaction.followUp(options);
  }
}