export const PrefixConfig = {
  PREFIX: "!",
};